<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card">
                    <div class="card-header">Dashboard</div>

                    <div class="card-body">
                        <p>All Listening questions</p>
                        <hr>

                        <?php $__currentLoopData = $allquestion ?? ''; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <ul>
                                <li>Listening Question <?php echo e($column->id); ?> ||
                                    <a href="<?php echo e(route('listening.ans',$column->id)); ?>">Start</a>
                                </li>
                            </ul>







                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sadiashamma/code/ielts/resources/views/listening.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card">
                    <div class="card-header">Listening Question no <?php echo e($questions->id); ?></div>
                    <div class="card-body">
                        <iframe width="850" height="400" src="https://www.youtube.com/embed/<?php echo e($questions->urls); ?>"
                                frameborder="0"
                                allow="accelerometer; encrypted-media;"
                        ></iframe>
                        <form class="form-inline" method="POST" action="/listeningans">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" value="<?php echo e($questions->id); ?>" name="listening_question_id">
                            <label for="urls">Write your Answer</label>
                            <div class="row">
                                <?php $__currentLoopData = range(0,39); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-3">
                                        <label for="<?php echo e($x); ?>"> <?php echo e($x+1); ?>.
                                            <input class="m-1 " type="text" name="ans[]" value="<?php echo e(old('ans.'.$x)); ?>">
                                        </label>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                            <div class="col-12 float-right mt-3">
                                <input class="btn-primary" type="submit" name="submit">
                            </div>
                        </form>
                        <?php if(Session::has('success')): ?>
                            <div class="alert alert-success">
                                <?php echo e(Session::get('success')); ?>

                            </div>
                        <?php endif; ?>
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sadiashamma/code/ielts/resources/views/listening_ans.blade.php ENDPATH**/ ?>
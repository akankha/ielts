<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card">
                    <div class="card-header">Result</div>

                    <div class="card-body">
                        <p>Your result is </p>
                        <h2>Your Got : <?php echo e($final_grade); ?></h2>
                        <h4>Points : <?php echo e($count); ?>/40</h4>
                        <ol class="list-group">
                            <?php for($i = 1; $i <=40 ; $i++): ?>
                                <li class="list-group-item"><?php echo e($i); ?>.

                                <?php if($origina_ans[$i]===$user_ans[$i]): ?>
                                        <div style="display: inline-block;color: green;">
                                            <?php echo e(ucfirst($origina_ans[$i])); ?> :: <?php echo e($user_ans[$i]); ?>

                                        </div>
                                    <?php else: ?>

                                           <div style="text-decoration: line-through;display: inline-block;color: #ff0000;">
                                               <?php echo e(ucfirst($origina_ans[$i])); ?> :: <?php echo e($user_ans[$i]); ?>

                                           </div>

                                <?php endif; ?>
                                </li>
                            <?php endfor; ?>
                        </ol>

                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sadiashamma/code/ielts/resources/views/result.blade.php ENDPATH**/ ?>